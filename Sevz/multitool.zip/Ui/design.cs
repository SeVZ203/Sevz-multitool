﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sevz.Ui
{
    public static class design
    {
        public static void PrintSevz()
        {
            //Console.WriteLine(" SSS  EEEEE  V   V  ZZZZZ ");
            //Console.WriteLine("S     E      V   V      Z ");
            //Console.WriteLine(" SSS  EEEEE   V V     Z   ");
            //Console.WriteLine("    S E        V     Z    ");
            //Console.WriteLine(" SSS  EEEEE    V    ZZZZZ ");
        }


    }
}

