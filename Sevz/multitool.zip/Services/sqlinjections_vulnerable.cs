﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Sevz.Models;

namespace Sevz.Services
{
    public class sqlinjections_vulnerable
    {
        public static void sqlinjection()
        {
            info.AlertWarning();
        }
    }
}
